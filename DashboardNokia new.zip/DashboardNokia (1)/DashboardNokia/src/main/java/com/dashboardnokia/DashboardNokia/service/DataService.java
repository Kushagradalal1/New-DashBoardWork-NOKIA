package com.dashboardnokia.DashboardNokia.service;

import com.dashboardnokia.DashboardNokia.model.ServerData;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static com.dashboardnokia.DashboardNokia.constant.Constant.USERNAME;
import static com.dashboardnokia.DashboardNokia.constant.Constant.REMOTE_HOST;
import static com.dashboardnokia.DashboardNokia.constant.Constant.REMOTE_PORT;
import static com.dashboardnokia.DashboardNokia.constant.Constant.PASSWORD;
import static com.dashboardnokia.DashboardNokia.constant.Constant.SESSION_TIMEOUT;
import static com.dashboardnokia.DashboardNokia.constant.Constant.CHANNEL_TIMEOUT;

@Service
public class DataService {

    public ServerData[] getData() {
        List<ServerData> jsonDataList = new ArrayList<>();
        Session jschSession = null;
        try {
            JSch jsch = new JSch();
            jsch.setConfig("StrictHostKeyChecking", "no");
            jschSession = jsch.getSession(USERNAME, REMOTE_HOST, REMOTE_PORT);
            jschSession.setPassword(PASSWORD);
            jschSession.connect(SESSION_TIMEOUT);
            ChannelExec channelExec = (ChannelExec) jschSession.openChannel("exec");
            channelExec.setCommand("sudo bash /var/fpwork2/APToolset/AP1/diskspace_htmltable_working_bhling119.sh");
            channelExec.setErrStream(System.err);
            InputStream in = channelExec.getInputStream();
            channelExec.connect(CHANNEL_TIMEOUT);
            StringBuilder sb = new StringBuilder();
            byte[] tmp = new byte[1024];
            while (true) {
                while (in.available() > 0) {
                    int i = in.read(tmp, 0, 1024);
                    if (i < 0) {
                        break;
                    }
                    sb.append(new String(tmp, 0, i));
                }
                if (channelExec.isClosed()) {
                    if (in.available() > 0) {
                        continue;
                    }
                    System.out.println("exit-status: " + channelExec.getExitStatus());
                    break;
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ignored) {
                }
            }
            channelExec.disconnect();
            String jsonDataStr = sb.toString();
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(jsonDataStr);
            JsonNode dataArray = rootNode.get("data");
            for (JsonNode data : dataArray) {
                JsonNode sizeNode = data.get("size");
                JsonNode colorNode = data.get("color");
                JsonNode fsNode = data.get("fs");
                JsonNode mountNode = data.get("mount");
                JsonNode percentNode = data.get("percent");
                if (sizeNode == null || colorNode == null || fsNode == null || mountNode == null || percentNode == null) {
                    continue;
                }
                String size = sizeNode.asText();
                String color = colorNode.asText();
                String fs = fsNode.asText();
                String mount = mountNode.asText();
                String percent = percentNode.asText();
                jsonDataList.add(new ServerData(size, color, fs, mount, percent));
            }
        } catch (JSchException | IOException e) {
            e.printStackTrace();
        } finally {
            if (jschSession != null) {
                jschSession.disconnect();
            }
        }

// Convert list to array
        ServerData[] jsonDataArray = new ServerData[jsonDataList.size()];
        jsonDataList.toArray(jsonDataArray);

        return jsonDataArray;

    }
}